#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionHilfe_triggered();

    void on_actionSchlie_en_triggered();

    void on_action_ffnen_triggered();

    void on_action_ffnen_4_triggered();

    void on_actionZufallsbild_triggered();

    void on_actionDatei_speichern_triggered();

    void on_pushButton_clicked();

    void on_actionDr_ckMich_triggered();

    void on_actionVerschl_sselung_triggered();

    void on_actionEntschl_sselung_triggered();

    void on_actionOverlays_triggered();

    void on_actionSpeichern_unter_triggered();

    void on_actionSchl_ssel_erstellen_triggered();

    void on_actionZufallsbild_erstellen_triggered();

    void on_actionSpiel_starten_triggered();

    void on_actionN_chster_Zeitschritt_triggered();

    void on_actionEigener_Zeitsprung_triggered();

    void on_actionZellen_bearbeiten_triggered();

    void on_actionZellen_umf_rben_triggered();

    void on_actionAutoren_triggered();

private:
    Ui::MainWindow *ui;
    QLabel *imageLabel;
};

#endif // MAINWINDOW_H
