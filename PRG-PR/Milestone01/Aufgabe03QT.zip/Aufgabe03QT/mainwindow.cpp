#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionHilfe_triggered()
{
    //help function
    QMessageBox::about(this,"Hilfe","Folgendes ist möglich: \n \n"
                                    "Optionen: Hier können sie das Hilfe Fenster öffnen und das Programm schließen."
                                    "\n \nKrypto.Funktionen: Hier können sie alle Funktionen zur Kryptographie auswählen."
                                    "\n \nGame of Life: Hier können sie Game of Life spielen."
                                    "\n \n \nWICHTIG: Dateien müssen zur Benutzung als .txt vorliegen und werden auch als"
                                    " solche abgespeichert, da es sonst zu Problemen kommen kann. Dateien werden spezifisch mit "
                                    " der Funktion speichern abgespeichert.");
}

void MainWindow::on_actionSchlie_en_triggered()
{
    //this function closes the apllication
    QCoreApplication::quit();
}

void MainWindow::on_action_ffnen_triggered()
{
    //preview function, it takes a chosen textfile and displays the content

    QString file_name = QFileDialog::getOpenFileName(this, "Bild öffnen...","C://");
    QFile file(file_name);

    if (!file.open(QFile::ReadWrite | QFile::Text)) {
        QMessageBox::warning(this,"Fehler!","Datei konnte nicht geöffnet werden! \nVersuchen sie es nochmals.");
    }
    QTextStream in(&file);
    QString text = in.readAll();
    ui->plainTextEdit->setPlainText(text);
    file.close();


}

void MainWindow::on_action_ffnen_4_triggered()
{
    //preview function, it takes a chosen textfile and displays the content

    QString file_name = QFileDialog::getOpenFileName(this, "Bild öffnen...","C://");
    QFile file(file_name);

    if (!file.open(QFile::ReadWrite | QFile::Text)) {
        QMessageBox::warning(this,"Fehler!","Datei konnte nicht geöffnet werden! \nVersuchen sie es nochmals.");
    }
    QTextStream in(&file);
    QString text = in.readAll();
    ui->plainTextEdit->setPlainText(text);
    file.close();


}

void MainWindow::on_actionZufallsbild_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionDatei_speichern_triggered()
{
    //this function lets the user save whatever is in the Text Edit field, uses the save
    //file dialog so that the user can choose where to save and what name the file has

    QString location = QFileDialog::getSaveFileName(this, "Datei speichern...","C://");
    QFile file(location);

    if (!file.open(QFile::ReadWrite | QFile::Text)) {
        QMessageBox::warning(this,"Fehler!","Fehler beim speichern der Datei! \nVersuchen Sie es erneut.");
    }
    QTextStream in(&file);
    QString text = ui->plainTextEdit->toPlainText();
    QTextStream out(&file);
    QString output = text;
    out << output;
    file.flush();
    file.close();
}

void MainWindow::on_pushButton_clicked()
{
    //placeholder as the game itself isn't imported
    QMessageBox::about(this,"Information...","Hier würde Game of Life stattfinden, wenn es in QT implementiert sein würde");
}

void MainWindow::on_actionDr_ckMich_triggered()
{
    //placeholder as the game itself isnt' imported
    QMessageBox::about(this,"Information...","Hier würde Game of Life stattfinden, wenn es in QT implementiert worden wäre");
}

void MainWindow::on_actionVerschl_sselung_triggered()
{
    //encrypting placeholder, but currently this function only opens a text file and copies the content into itself, it multiplies
    //the user can choose which file is used

    QString location = QFileDialog::getOpenFileName(this, "Text zum Multiplizieren wählen...","C://");
    QFile file(location);

    if (!file.open(QFile::ReadWrite | QFile::Text)) {
        QMessageBox::warning(this,"Fehler","Es gab einen Fehler beim Öffnen! \nVersuchen Sie es erneut.");
    }
    QTextStream in(&file);
    QString text = in.readAll();
    QTextStream out(&file);
    QString output = text;
    out << output;
    file.flush();
    file.close();
}

void MainWindow::on_actionEntschl_sselung_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionOverlays_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionSpeichern_unter_triggered()
{
    //this function lets the user save whatever is in the Text Edit field, uses the save
    //file dialog so that the user can choose where to save and what name the file has

    QString location = QFileDialog::getSaveFileName(this, "Datei speichern...","C://");
    QFile file(location);

    if (!file.open(QFile::ReadWrite | QFile::Text)) {
        QMessageBox::warning(this,"Fehler!","Fehler beim speichern der Datei! \nVersuchen Sie es erneut.");
    }
    QTextStream in(&file);
    QString text = ui->plainTextEdit->toPlainText();
    QTextStream out(&file);
    QString output = text;
    out << output;
    file.flush();
    file.close();
}

void MainWindow::on_actionSchl_ssel_erstellen_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionZufallsbild_erstellen_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionSpiel_starten_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionN_chster_Zeitschritt_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionEigener_Zeitsprung_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionZellen_bearbeiten_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionZellen_umf_rben_triggered()
{
    QMessageBox::warning(this,"Information","Dies ist ein Platzhalter für wie das fertige Programm eigentlich"
                                            " aussehen würde, da die Funktion nicht implementiert werden konnte");
}

void MainWindow::on_actionAutoren_triggered()
{
    QMessageBox::about(this,"Information","Die Autoren dieses Programms sind: \n \n"
                                            "Cedric Berger, Niklas Dillenberger und Sorin Echim");
}
